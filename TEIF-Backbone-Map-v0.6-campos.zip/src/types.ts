// Uma métrica configurável associada a um POP ou enlace.
export type MonitorUnit = 'auto' | 'bps' | 'Bps' | 'percent' | 'ms' | 'dBm' | 'none';

export interface MonitorField {
  id: string;
  name: string;
  queryRefId: string;
  itemKey: string;
  unit: MonitorUnit;
}

export interface BackbonePop {
  id: string;
  name: string;
  latitude: number;
  longitude: number;
  monitoringFields?: MonitorField[];
}

export interface BackboneLink {
  id: string;
  name: string;
  sourcePopId: string;
  targetPopId: string;
  color: string;
  width: number;
  monitoringFields?: MonitorField[];
}

export interface SimpleOptions {
  latitude?: number;
  longitude?: number;
  zoom?: number;

  pops?: BackbonePop[];
  links?: BackboneLink[];
}
