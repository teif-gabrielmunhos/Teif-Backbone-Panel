import { FieldType } from '@grafana/data';
import type { DataFrame, Field, PanelData } from '@grafana/data';
import type { MonitorField, MonitorUnit } from './types';

/**
 * Faz a ponte entre os campos de monitoramento e o resultado real das queries.
 * A associação usa refId + identidade da série + campo + labels.
 * Em caso de séries absolutamente idênticas, adicionamos um ordinal.
 */
export interface QueryItem {
  key: string;
  queryRefId: string;
  label: string;
  field: Field;
}

function sortedLabels(labels?: Record<string, string>): Array<[string, string]> {
  return Object.entries(labels ?? {}).sort(([a], [b]) => a.localeCompare(b));
}

export function availableQueryItems(series: DataFrame[]): QueryItem[] {
  const items: QueryItem[] = [];
  const seen = new Map<string, number>();

  for (const frame of series ?? []) {
    const queryRefId = frame.refId ?? '';
    for (const field of frame.fields) {
      if (
        field.type !== FieldType.number &&
        field.type !== FieldType.string &&
        field.type !== FieldType.boolean
      ) {
        continue;
      }

      // Chave não depende da posição global da série no resultado do Grafana.
      const identity = JSON.stringify({
        q: queryRefId,
        s: frame.name ?? '',
        f: field.name,
        fl: sortedLabels(field.labels),
      });
      const ordinal = seen.get(identity) ?? 0;
      seen.set(identity, ordinal + 1);
      const key = `${identity}#${ordinal}`;

      const labelFromGrafana = field.config?.displayName || field.config?.displayNameFromDS;
      const labelsText = sortedLabels(field.labels).map(([k, v]) => `${k}=${v}`).join(', ');
      const seriesLabel = frame.name || labelsText || 'Série sem nome';
      const fieldLabel = labelFromGrafana || field.name;
      const label = `${seriesLabel} → ${fieldLabel}${labelsText && frame.name ? ` (${labelsText})` : ''}`;

      items.push({ key, queryRefId, label, field });
    }
  }
  return items;
}

export function availableQueryIds(data: PanelData): string[] {
  const ids = [
    ...(data.request?.targets ?? []).map((target) => target.refId),
    ...data.series.map((frame) => frame.refId ?? ''),
  ];
  return [...new Set(ids.filter((id): id is string => Boolean(id)))].sort();
}

function lastValidValue(field: Field): unknown {
  const values = field.values;
  if (!values) { return undefined; }
  // Compatível com arrays atuais e os Vectors presentes em versões mais antigas.
  const vector = values as unknown as { length: number; get?: (index: number) => unknown; [index: number]: unknown };
  for (let i = vector.length - 1; i >= 0; i--) {
    const value = typeof vector.get === 'function' ? vector.get(i) : vector[i];
    if (value !== null && value !== undefined && value !== '' && !(typeof value === 'number' && !Number.isFinite(value))) {
      return value;
    }
  }
  return undefined;
}

function formatValue(value: unknown, unit: MonitorUnit, field: Field): string {
  if (typeof value !== 'number') { return String(value); }
  if (unit === 'auto') {
    const rendered = field.display?.(value);
    if (rendered) { return [rendered.text, rendered.suffix].filter(Boolean).join(' '); }
  }
  const number = (n: number) => new Intl.NumberFormat('pt-BR', { maximumFractionDigits: 2 }).format(n);
  if (unit === 'bps' || unit === 'Bps') {
    const suffixes = unit === 'bps' ? ['bps', 'Kbps', 'Mbps', 'Gbps', 'Tbps'] : ['B/s', 'KB/s', 'MB/s', 'GB/s', 'TB/s'];
    let scaled = value;
    let index = 0;
    while (Math.abs(scaled) >= 1000 && index < suffixes.length - 1) { scaled /= 1000; index++; }
    return `${number(scaled)} ${suffixes[index]}`;
  }
  if (unit === 'percent') { return `${number(value)} %`; }
  if (unit === 'ms') { return `${number(value)} ms`; }
  if (unit === 'dBm') { return `${number(value)} dBm`; }
  return number(value);
}

export function metricValue(config: MonitorField, available: QueryItem[]): string {
  if (!config.queryRefId || !config.itemKey) { return 'Não configurado'; }
  const item = available.find((candidate) => candidate.key === config.itemKey && candidate.queryRefId === config.queryRefId);
  if (!item) { return 'Item não encontrado'; }
  const raw = lastValidValue(item.field);
  if (raw === undefined) { return 'Sem dados'; }
  return formatValue(raw, config.unit, item.field);
}
