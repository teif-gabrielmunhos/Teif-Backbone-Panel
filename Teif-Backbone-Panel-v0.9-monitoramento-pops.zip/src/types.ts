// Uma métrica configurável associada a um POP ou enlace.
export type MonitorUnit = 'auto' | 'bps' | 'Bps' | 'percent' | 'ms' | 'dBm' | 'none';

export interface MonitorField {
  id: string;
  name: string;
  queryRefId: string;
  itemKey: string;
  unit: MonitorUnit;
  /** Regra individual de ATENÇÃO aplicável a POPs e enlaces. */
  warningRule?: FieldWarningRule;
}

/** Operadores para as regras de atenção e de indisponibilidade. */
export type AlertOperator = 'eq' | 'ne' | 'gt' | 'gte' | 'lt' | 'lte';

export interface FieldWarningRule {
  operator: AlertOperator;
  value: string;
}

/** Regra de DOWN (vermelho) com prioridade máxima, em POPs e enlaces. */
export interface LinkAlertRule {
  fieldId: string;
  operator: AlertOperator;
  value: string;
}

/** Mesmo formato de configuração da regra DOWN de um enlace. */
export type PopAlertRule = LinkAlertRule;

export interface BackbonePop {
  id: string;
  name: string;
  latitude: number;
  longitude: number;
  monitoringFields?: MonitorField[];
  /** Opcional: campo e condição que deixam o POP vermelho pulsante. */
  alertRule?: PopAlertRule;
}

export interface BackboneLink {
  id: string;
  name: string;
  sourcePopId: string;
  targetPopId: string;
  color: string;
  width: number;
  monitoringFields?: MonitorField[];
  alertRule?: LinkAlertRule;
}

export interface SimpleOptions {
  latitude?: number;
  longitude?: number;
  zoom?: number;

  pops?: BackbonePop[];
  links?: BackboneLink[];
}
