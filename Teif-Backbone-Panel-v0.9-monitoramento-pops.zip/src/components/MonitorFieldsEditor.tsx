import React from 'react';
import { Button } from '@grafana/ui';
import type { AlertOperator, MonitorField, MonitorUnit } from '../types';
import type { QueryItem } from '../monitoring';
import { evaluateMonitorRule, metricValue } from '../monitoring';

interface Props {
  fields: MonitorField[];
  queryIds: string[];
  items: QueryItem[];
  onChange: (next: MonitorField[]) => void;
  /** Permite thresholds individuais de atenção em POPs e enlaces. */
  enableWarningThresholds?: boolean;
}

const inputStyle: React.CSSProperties = {
  width: '100%',
  boxSizing: 'border-box',
  padding: '7px',
  background: '#111827',
  color: '#fff',
  border: '1px solid #526174',
  borderRadius: 4,
};
const labelStyle: React.CSSProperties = { display: 'block', fontSize: 12, color: '#c8d6e5', marginBottom: 3 };

function newField(): MonitorField {
  return {
    id: `monitor-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    name: 'Novo campo',
    queryRefId: '',
    itemKey: '',
    unit: 'auto',
  };
}

export const MonitorFieldsEditor: React.FC<Props> = ({ fields, queryIds, items, onChange, enableWarningThresholds = false }) => {
  const changeOne = (id: string, patch: Partial<MonitorField>) =>
    onChange(fields.map((field) => field.id === id ? { ...field, ...patch } : field));

  const move = (index: number, offset: number) => {
    const target = index + offset;
    if (target < 0 || target >= fields.length) { return; }
    const result = [...fields];
    [result[index], result[target]] = [result[target], result[index]];
    onChange(result);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
      <strong>Campos de monitoramento</strong>
      {queryIds.length === 0 && (
        <small style={{ color: '#fbbf24' }}>Nenhuma query detectada. Configure uma consulta na aba Queries do Grafana e aguarde a coleta.</small>
      )}
      {fields.map((field, index) => {
        const matchingItems = items.filter((item) => item.queryRefId === field.queryRefId);
        const chosenItemExists = matchingItems.some((item) => item.key === field.itemKey);
        return (
          <div key={field.id} style={{ padding: 9, background: '#182437', border: '1px solid #3a4e65', borderRadius: 6, display: 'flex', flexDirection: 'column', gap: 8 }}>
            <div style={{ display: 'flex', gap: 4, justifyContent: 'flex-end' }}>
              <Button size="sm" variant="secondary" disabled={index === 0} onClick={() => move(index, -1)}>↑</Button>
              <Button size="sm" variant="secondary" disabled={index === fields.length - 1} onClick={() => move(index, 1)}>↓</Button>
              <Button size="sm" variant="secondary" onClick={() => onChange(fields.filter((f) => f.id !== field.id))}>Remover</Button>
            </div>
            <div>
              <label style={labelStyle}>Nome do campo</label>
              <input style={inputStyle} maxLength={64} value={field.name} onChange={(e) => changeOne(field.id, { name: e.target.value })} />
            </div>
            <div>
              <label style={labelStyle}>Query do Grafana</label>
              <select style={inputStyle} value={field.queryRefId} onChange={(e) => changeOne(field.id, { queryRefId: e.target.value, itemKey: '' })}>
                <option value="">Selecione a query</option>
                {queryIds.map((id) => <option key={id} value={id}>{id}</option>)}
                {field.queryRefId && !queryIds.includes(field.queryRefId) && <option value={field.queryRefId}>{field.queryRefId} (indisponível)</option>}
              </select>
            </div>
            <div>
              <label style={labelStyle}>Item / série retornado pela query</label>
              <select style={inputStyle} value={field.itemKey} disabled={!field.queryRefId || matchingItems.length === 0} onChange={(e) => changeOne(field.id, { itemKey: e.target.value })}>
                <option value="">Selecione o item</option>
                {matchingItems.map((item) => <option key={item.key} value={item.key}>{item.label}</option>)}
                {field.itemKey && !chosenItemExists && <option value={field.itemKey}>Item anteriormente selecionado (indisponível)</option>}
              </select>
            </div>
            <div>
              <label style={labelStyle}>Unidade</label>
              <select style={inputStyle} value={field.unit} onChange={(e) => changeOne(field.id, { unit: e.target.value as MonitorUnit })}>
                <option value="auto">Automática (Grafana)</option>
                <option value="bps">bits/s</option>
                <option value="Bps">bytes/s</option>
                <option value="percent">%</option>
                <option value="ms">ms</option>
                <option value="dBm">dBm</option>
                <option value="none">Número sem unidade</option>
              </select>
            </div>
            {enableWarningThresholds && (
              <div style={{ borderTop: '1px solid #405065', paddingTop: 9, display: 'flex', flexDirection: 'column', gap: 7 }}>
                <label style={{ ...labelStyle, display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer' }}>
                  <input
                    type="checkbox"
                    style={{ width: 16, height: 16, flexShrink: 0 }}
                    checked={Boolean(field.warningRule)}
                    onChange={(event) => changeOne(field.id, {
                      warningRule: event.target.checked ? { operator: 'gt', value: '0' } : undefined,
                    })}
                  />
                  Threshold de atenção (indicador amarelo)
                </label>
                {field.warningRule && (
                  <>
                    <label style={labelStyle}>Condição para ficar amarelo</label>
                    <select
                      style={inputStyle}
                      value={field.warningRule.operator}
                      onChange={(event) => changeOne(field.id, {
                        warningRule: { ...field.warningRule!, operator: event.target.value as AlertOperator },
                      })}
                    >
                      <option value="eq">Igual a (=)</option>
                      <option value="ne">Diferente de (≠)</option>
                      <option value="gt">Maior que (&gt;)</option>
                      <option value="gte">Maior ou igual (≥)</option>
                      <option value="lt">Menor que (&lt;)</option>
                      <option value="lte">Menor ou igual (≤)</option>
                    </select>
                    <label style={labelStyle}>Valor limite (na unidade bruta da query)</label>
                    <input
                      style={inputStyle}
                      value={field.warningRule.value}
                      placeholder="Ex.: 1000000000, 75 ou 100"
                      onChange={(event) => changeOne(field.id, {
                        warningRule: { ...field.warningRule!, value: event.target.value },
                      })}
                    />
                    <small style={{ color: '#facc15' }}>
                      Condição: {({ alert: 'ULTRAPASSADA', ok: 'Normal', 'no-data': 'Sem dados / condição inválida' } as const)[
                        evaluateMonitorRule(field.warningRule, field, items)
                      ]}
                    </small>
                  </>
                )}
              </div>
            )}
            <small style={{ color: '#b5e4ff' }}>Último valor: {metricValue(field, items)}</small>
          </div>
        );
      })}
      <Button size="sm" variant="primary" onClick={() => onChange([...fields, newField()])}>+ Adicionar campo</Button>
    </div>
  );
};

export const MonitorFieldsReadout: React.FC<{ fields: MonitorField[]; items: QueryItem[] }> = ({ fields, items }) => (
  <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
    {fields.length === 0 ? (
      <small style={{ color: '#aebcd0' }}>Nenhum campo de monitoramento configurado.</small>
    ) : (
      fields.map((field) => (
        <div key={field.id} style={{ display: 'flex', justifyContent: 'space-between', gap: 10, borderBottom: '1px solid #2c3c50', paddingBottom: 4 }}>
          <span style={{ overflowWrap: 'anywhere' }}>{field.name || 'Campo sem nome'}</span>
          <strong style={{ textAlign: 'right', whiteSpace: 'nowrap' }}>{metricValue(field, items)}</strong>
        </div>
      ))
    )}
  </div>
);
