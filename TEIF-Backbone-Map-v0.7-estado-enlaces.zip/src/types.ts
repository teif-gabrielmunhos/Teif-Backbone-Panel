// Uma métrica configurável associada a um POP ou enlace.
export type MonitorUnit = 'auto' | 'bps' | 'Bps' | 'percent' | 'ms' | 'dBm' | 'none';

export interface MonitorField {
  id: string;
  name: string;
  queryRefId: string;
  itemKey: string;
  unit: MonitorUnit;
}

/** Regra opcional usada APENAS para alterar a aparência do enlace. */
export type AlertOperator = 'eq' | 'ne' | 'gt' | 'gte' | 'lt' | 'lte';

export interface LinkAlertRule {
  fieldId: string;
  operator: AlertOperator;
  value: string;
}

export interface BackbonePop {
  id: string;
  name: string;
  latitude: number;
  longitude: number;
  monitoringFields?: MonitorField[];
}

export interface BackboneLink {
  id: string;
  name: string;
  sourcePopId: string;
  targetPopId: string;
  color: string;
  width: number;
  monitoringFields?: MonitorField[];
  alertRule?: LinkAlertRule;
}

export interface SimpleOptions {
  latitude?: number;
  longitude?: number;
  zoom?: number;

  pops?: BackbonePop[];
  links?: BackboneLink[];
}
